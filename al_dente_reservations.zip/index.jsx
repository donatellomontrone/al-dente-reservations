import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectContent, SelectItem } from "@/components/ui/select";

export default function AlDenteReservations() {
  const [date, setDate] = useState(new Date());
  const [name, setName] = useState("");
  const [guests, setGuests] = useState("");
  const [note, setNote] = useState("");
  const [time, setTime] = useState("");
  const [area, setArea] = useState("");
  const [eventPackage, setEventPackage] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [adminView, setAdminView] = useState(false);
  const [reservations, setReservations] = useState([]);

  const handleReservation = () => {
    if (name && guests && date && time && area) {
      const newReservation = {
        name,
        guests,
        date: date.toDateString(),
        time,
        area,
        note,
        eventPackage,
      };
      setReservations([...reservations, newReservation]);
      setConfirmed(true);
      setName("");
      setGuests("");
      setNote("");
      setTime("");
      setArea("");
      setEventPackage("");
    }
  };

  return (
    <div className="min-h-screen bg-white px-4 py-6 flex flex-col items-center justify-center">
      <Card className="w-full max-w-sm sm:max-w-md mb-8">
        <CardContent className="space-y-4">
          <h1 className="text-xl sm:text-2xl font-bold text-center">Al Dente Reservations</h1>

          <Input placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
          <Input placeholder="Number of guests" type="number" value={guests} onChange={(e) => setGuests(e.target.value)} />

          <div className="rounded-md border">
            <Calendar selected={date} onSelect={setDate} className="w-full" />
          </div>

          <Select onValueChange={setTime} value={time}>
            <SelectTrigger className="w-full">Time</SelectTrigger>
            <SelectContent>
              <SelectItem value="11:00 AM">11:00 AM</SelectItem>
              <SelectItem value="1:00 PM">1:00 PM</SelectItem>
              <SelectItem value="6:00 PM">6:00 PM</SelectItem>
              <SelectItem value="8:00 PM">8:00 PM</SelectItem>
            </SelectContent>
          </Select>

          <Select onValueChange={setArea} value={area}>
            <SelectTrigger className="w-full">Area</SelectTrigger>
            <SelectContent>
              <SelectItem value="Indoor">Indoor</SelectItem>
              <SelectItem value="Outdoor">Outdoor</SelectItem>
              <SelectItem value="Full Venue (Private Event)">Full Venue (Private Event)</SelectItem>
            </SelectContent>
          </Select>

          <Select onValueChange={setEventPackage} value={eventPackage}>
            <SelectTrigger className="w-full">Event Package (optional)</SelectTrigger>
            <SelectContent>
              <SelectItem value="None">None</SelectItem>
              <SelectItem value="₱30,000 - Indoor (consumable)">₱30,000 - Indoor (consumable)</SelectItem>
              <SelectItem value="₱80,000 - Full Venue (consumable)">₱80,000 - Full Venue (consumable)</SelectItem>
            </SelectContent>
          </Select>

          <Textarea
            placeholder="Any notes (ex. birthday, allergies...)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />

          <Button className="w-full" onClick={handleReservation}>Confirm Reservation</Button>

          {confirmed && (
            <div className="text-green-600 text-center font-semibold">
              Reservation confirmed!
            </div>
          )}
        </CardContent>
      </Card>

      <Button variant="outline" onClick={() => setAdminView(!adminView)}>
        {adminView ? "Hide Admin Panel" : "Show Admin Panel"}
      </Button>

      {adminView && (
        <Card className="w-full max-w-2xl mt-6">
          <CardContent className="space-y-4">
            <h2 className="text-lg sm:text-xl font-bold text-center">Admin Reservation List</h2>
            {reservations.length === 0 ? (
              <p className="text-center">No reservations yet.</p>
            ) : (
              reservations.map((res, index) => (
                <div key={index} className="border-b py-2 text-sm sm:text-base">
                  <div><strong>{res.name}</strong> – {res.guests} guests</div>
                  <div>{res.date} at {res.time} – {res.area}</div>
                  {res.eventPackage !== "None" && <div>Package: {res.eventPackage}</div>}
                  {res.note && <div>Note: {res.note}</div>}
                </div>
              ))
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
